import React from 'react';
import { Link } from 'react-router-dom';



function MovieCard({ movie }) {
  return (
    <div >
      <div className="card bg-gray-800 text-white rounded-lg overflow-hidden shadow-lg w-64 h-96 ">
        <div className="w-full h-64">
        <Link to={`/movies/${movie.id}`} >
          <div className='p-4 hover:text-gray-900 active:text-teal-100'>
            <img
            src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`}
            alt=""
            className="w-full h-full object-fill"
            />
            </div>
          </Link> 
        </div>
        <div className="p-4">
          <p className="text-yellow-400 text-xl">⭐️ {movie.vote_average}</p>
          <p className="text-xl font-bold">{movie.title}</p>
          <p className="mt-2">{movie.release_date}</p>
        </div>
      </div>
    </div>
  );
}

export default MovieCard;
