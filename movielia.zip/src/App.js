import './App.css';
import { HomePage } from './Pages/HomePage';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom'
import MovieDetail from './Pages/MovieDetail';



function App() {
  return (
    <><div><HomePage /></div>
    
      <Routes>
        <Route path="movies/:id" element={<MovieDetail />} />
      </Routes>
    
    </>
  );
}

export default App;
